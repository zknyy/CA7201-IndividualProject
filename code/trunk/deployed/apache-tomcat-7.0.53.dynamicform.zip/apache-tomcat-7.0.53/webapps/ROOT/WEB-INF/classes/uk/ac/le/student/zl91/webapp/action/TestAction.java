package uk.ac.le.student.zl91.webapp.action;

import org.appfuse.service.GenericManager;
import uk.ac.le.student.zl91.model.Qu;
import uk.ac.le.student.zl91.model.Te;
import uk.ac.le.student.zl91.model.Template;
import uk.ac.le.student.zl91.service.QuestionManager;

/**
 * The class is
 * <p/>
 * Created by Zhipeng Liang (ZL91) on 2014/4/11.
 * For the individual project(CO7201) with University of Leicester in 2014.
 */
public class TestAction extends BaseAction {

    private GenericManager<Te, Long> teManager;
    private GenericManager<Qu, Long> quManager;
    private GenericManager<Template, Long> templateManager;
    private QuestionManager questionManager;

    public GenericManager<Te, Long> getTeManager() {
        return teManager;
    }

    public void setTeManager(GenericManager<Te, Long> teManager) {
        this.teManager = teManager;
    }

    public GenericManager<Qu, Long> getQuManager() {
        return quManager;
    }

    public void setQuManager(GenericManager<Qu, Long> quManager) {
        this.quManager = quManager;
    }

    public GenericManager<Template, Long> getTemplateManager() {
        return templateManager;
    }

    public void setTemplateManager(GenericManager<Template, Long> templateManager) {
        this.templateManager = templateManager;
    }

    public QuestionManager getQuestionManager() {
        return questionManager;
    }

    public void setQuestionManager(QuestionManager questionManager) {
        this.questionManager = questionManager;
    }

    public String test(){
        this.getRequest().setAttribute("teManager",teManager);
        this.getRequest().setAttribute("quManager",quManager);
        this.getRequest().setAttribute("templateManager",templateManager);
        this.getRequest().setAttribute("questionManager",questionManager);

        return SUCCESS;
    }
}
