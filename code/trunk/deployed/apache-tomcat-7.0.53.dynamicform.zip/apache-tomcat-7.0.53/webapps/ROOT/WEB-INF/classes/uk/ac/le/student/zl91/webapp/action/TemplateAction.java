package uk.ac.le.student.zl91.webapp.action;

import org.appfuse.service.GenericManager;
import org.springframework.beans.factory.annotation.Autowired;
import uk.ac.le.student.zl91.model.Answer;
import uk.ac.le.student.zl91.model.Question;
import uk.ac.le.student.zl91.model.Template;
import uk.ac.le.student.zl91.model.TemplateStatus;
import uk.ac.le.student.zl91.service.QuestionManager;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

/**
 * The class is
 * <p/>
 * Created by Zhipeng Liang (ZL91) on 2014/4/1.
 * For the individual project(CO7201) with University of Leicester in 2014.
 */
public class TemplateAction extends BaseAction {

    private QuestionManager questionManager;
    private GenericManager<Template, Long> templateManager;
    private List templates;

    public void setTemplateManager(GenericManager<Template, Long> templateManager) {
        this.templateManager = templateManager;
    }
    public void setQuestionManager(QuestionManager questionManager) {
        this.questionManager = questionManager;
    }


//    public void setTemplateManager(GenericManager<Template, Long> templateManager) {
//        this.templateManager = templateManager;
//    }

    public List getTemplates() {
        return templates;
    }

    public String list() {
        templates = templateManager.getAll();
        log.debug("templates.size:"+templates.size());
        return SUCCESS;
    }


    private Template template;
    private Long tid;

    public void setTid(Long tid) {
        this.tid = tid;
    }

    public Template getTemplate() {
        return template;
    }

    public void setTemplate(Template template) {
        this.template = template;
    }

    public String delete() {
        templateManager.remove(template.getTid());
        saveMessage(getText("template.deleted"));

        return SUCCESS;
    }

    public String discard() {
        this.template = this.templateManager.get(this.tid);
        template.setStatus(TemplateStatus.DISCARDED);
        this.templateManager.save(this.template);
        return SUCCESS;
    }

    List<Question> availableQuestionList;
    public List<Question> getAvailableQuestionList() {
        return availableQuestionList;
    }

    public String edit() {
        this.availableQuestionList = this.questionManager.getAll();

        log.debug("tid:" + tid);
        if (tid != null) {
            template = templateManager.get(tid);
        } else {
            template = new Template();
        }
        log.debug("template:"+template);
        return SUCCESS;
    }

    public String save() throws Exception {
        this.availableQuestionList = this.questionManager.getAll();

        if (cancel != null) {
            return CANCEL;
        }

        if (delete != null) {
            return delete();
        }

        boolean isNew = false;
        if(template.getTid() == null) {
            isNew=true;
            this.template = this.templateManager.save(template);
        }else{
            this.template.setQuestionSet(
                    this.templateManager.get(this.template.getTid()).getQuestionSet());
        }


        log.debug("template:"+template);
        log.debug("this.template.getQuestionSet().size():"
                + this.template.getQuestionSet().size());

        String[] questions = getRequest().getParameterValues("questions");
        log.debug("questions:"+ Arrays.toString(questions));


        //remove the relation between the template and all its question
        for (Question q : this.template.getQuestionSet()){
            log.debug("before q:"+q);
            q.setTemplate(null);
            log.debug("delete q:"+q);
            this.questionManager.save(q);
        }

        this.template.getQuestionSet().clear();//for showing the result on page
        log.debug("1. template.getQuestionSet().size():"+ template.getQuestionSet().size());
//        this.templateManager.save(template);

        if (questions != null) {
            for (String q : questions) {
                Question question = this.questionManager.get(Long.parseLong(q));
                question.setTemplate(this.template);//save the tid in the question table(really do it in database)
                this.questionManager.save(question);
                this.template.getQuestionSet().add(question);//for show the result on page
            }
        }

        log.debug("2. template.getQuestionSet().size():"+ template.getQuestionSet().size());
        this.template = this.templateManager.save(template);

        String key ;
        if(isNew){
            key ="template.added";
        }
        else{
            key="template.updated";
        }
        saveMessage(getText(key));

        if (isNew) {
            return SUCCESS;//created a new, then go to List
        } else {
            return INPUT;//updated an existed one, keep staying on the page
        }
    }
}